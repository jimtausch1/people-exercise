import React from "react";
import { Link } from 'react-router-dom';
import styles from "./PeopleHome.module.scss";
import PeopleList from "../people/PeopleList";

function PeopleHome() {
  // need to get the current count of people
  const [count, setCount] = React.useState(0);

  return (
    <>
      <div className={styles.App}>
        <h1>People Exercise</h1>
        <div className={styles.header}>
          <h2>total people: {count}</h2>
          <h2><Link to="/form">Add Person</Link></h2>
        </div>        
        <PeopleList setCount={setCount} />      
        <div className={styles.footer}>
          <a
            href="https://github.com/relode-dev/people-exercise"
            target="_blank"
            rel="noreferrer"
          >
            visit this project&apos;s github page
          </a>
        </div>
      </div>
    </>    
  );
}

export default PeopleHome;
