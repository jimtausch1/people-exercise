import * as React from "react";
import styles from "./PeopleList.module.scss";
import * as services from "../dataServices";
import { useLocation, useNavigate } from "react-router-dom";
import { Person } from "../types";

const initialPerson = {
  id: -1,
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  note: ""
} as Person;

const PeopleForm = () => {
  const [person, setPerson] = React.useState(initialPerson);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState('');
  const location = useLocation();
  const navigate = useNavigate();
  
  React.useEffect(() => {
    const fn = async () => {
      if (location.state && typeof(location.state) === 'number') {
        setLoading(true);
        const retrievedPerson = await services.retrievePerson(location.state as number);
        setLoading(false);
        setPerson(retrievedPerson);
      }
    };
    fn();
  }, []);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) : void => {
    const value = event.target.value;
    setPerson({...person, [event.target.name]: value});
  }

  const handleSubmit = async (event: React.MouseEvent<HTMLButtonElement>) : Promise<void> => {
    event.preventDefault();
    if (!person.firstName || !person.lastName || !person.email || !person.phone) {
      setError('* is required');
      const firstNameError = document.getElementById('firstNameError');
      if (firstNameError) {
        firstNameError.style.display = person.firstName ? "none" : "inline";
      }

      const lastNameError = document.getElementById('lastNameError');
      if (lastNameError) {
        lastNameError.style.display = person.lastName ? "none" : "inline";
      }

      const emailError = document.getElementById('emailError');
      if (emailError) {
        emailError.style.display = person.email ? "none" : "inline";
      }

      const phoneError = document.getElementById('phoneError');
      if (phoneError) {
        phoneError.style.display = person.phone ? "none" : "inline";
      }     
      
      return;
    }

    setLoading(true);
    if (location.state && typeof(location.state) === 'number') {
      const personParam = {...person, id: location.state as number}
      await services.updatePerson(personParam);
    } else {
      const nextId = await services.retrieveNext();
      if (typeof(nextId) === "number") {
        const personParam = {...person, id: nextId}
        await services.createPerson(personParam);
      }      
    }
    
    setLoading(false);
    navigate("/");
  }

  return (
    <div className={styles.PersonForm}>
      <h1>People Exercise Form</h1>
      {loading && <h4>...Loading</h4>}
      <form>
        <label>First Name:</label>
        <input type="text" name="firstName" required maxLength={50} value={person.firstName} onChange={handleChange}/>
        <span style={{display: 'none', color: "darkred"}} id="firstNameError">{error}</span>
        <br/>

        <label>Last Name:</label>
        <input type="text" name="lastName" required maxLength={50} value={person.lastName} onChange={handleChange}/>
        <span style={{display: 'none', color: "darkred"}} id="lastNameError">{error}</span>
        <br/>

        <label>Email:</label>
        <input type="text" name="email" required value={person.email} onChange={handleChange}/>
        <span style={{display: 'none', color: "darkred"}} id="emailError">{error}</span>
        <br/>

        <label>Phone:</label>
        <input type="text" name="phone" required value={person.phone} onChange={handleChange}/>
        <span style={{display: 'none', color: "darkred"}} id="phoneError">{error}</span>
        <br/>

        <label>Note:</label>
        <input type="text" name="note" maxLength={500} value={person.note} onChange={handleChange}/>
        <br/>

        <button type="submit" onClick={handleSubmit}>Submit Form</button>
        <button onClick={() => navigate("/")}>Cancel</button>
      </form>
    </div>    
  );
};

export default PeopleForm;