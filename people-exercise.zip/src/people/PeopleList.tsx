import * as React from "react";
import styles from "./PeopleList.module.scss";
import * as services from "../dataServices";
import { useNavigate } from "react-router-dom";
import { Person, PeopleListProps } from "../types";

const PeopleList = (props: PeopleListProps) => {
  const [data, setData] = React.useState<Person[]>([]);
  const [loading, setLoading] = React.useState(false);  
  const navigate = useNavigate();

  React.useEffect(() => {
    const fn = async () => {
      setLoading(true);
      const people = await services.retrievePeople();
      setLoading(false);
      props.setCount(people.length);
      setData(people);      
    };
    fn();    
  }, []);

  const handleClick = (id: number) : void => {
    navigate("/form", {state: id});
  }

  const handleDelete = async (id: number) : Promise<void> => {
    if (window.confirm('Are you sure you wish to delete this item?')) {
      setLoading(true);
      services.deletePerson(id);
      const people = await services.retrievePeople();
      setLoading(false); 
      props.setCount(people.length)
      setData(people);      
    } 
  }

  return (
    <>
      {loading && <h4>...Loading</h4>}
      <div className={styles.PersonList}>
        <div className={styles.PersonListHeader}>
          <span>First Name</span>
          <span>Last Name</span>
          <span>Email</span>
          <span>Phone</span>
          <span>Note</span>
          <span>Actions</span>
        </div>
      {data.map((p: Person) => (
        <div key={p.id} className={styles.PersonListItem}>
          <span>{p.firstName}</span>
          <span>{p.lastName}</span>
          <span>{p.email}</span>
          <span>{p.phone}</span>
          <span>{p.note}</span>
          <span>
            <a onClick={() => handleClick(p.id)}>Edit</a>&nbsp;
            <a onClick={() => handleDelete(p.id)}>Delete</a>
          </span>
        </div>
      ))}
      </div>
    </>    
  );
};

export default PeopleList;
