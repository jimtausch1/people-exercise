export interface Person {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  note: string;
}

export interface PeopleListProps {
  setCount: (countParam: number) => void; 
}

export interface PeopleFormProps {
  personId: number;
}

