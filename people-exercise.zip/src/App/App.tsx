import React from "react";
import { Route, Routes } from 'react-router-dom';
import PeopleForm from "../people/PeopleForm";
import PeopleHome from "../people/PeopleHome";

function App() {  
  return (
    <div>
      <Routes>
        <Route path="/" element={<PeopleHome/>} />
        <Route path="/form" element={<PeopleForm/>} />
      </Routes>        
    </div> 
  );
}

export default App;
